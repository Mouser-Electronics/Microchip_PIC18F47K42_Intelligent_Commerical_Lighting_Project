/*
 * Touch Driver, the firmware for the QT7 Xplained Pro
 * 
       Copyright (C) 2021  Mouser Electronics

       This program is free software: you can redistribute it and/or modify

       it under the terms of the GNU General Public License as published by

       the Free Software Foundation, either version 3 of the License, or

       any later version.

       This program is distributed in the hope that it will be useful,

       but WITHOUT ANY WARRANTY; without even the implied warranty of

       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

       GNU General Public License for more details.

       You should have received a copy of the GNU General Public License

       along with this program.  If not, see <http://www.gnu.org/licenses/>.

              Project BOM:

              (BOM weblink here)  
*/
#include "touch_app.h"
#include "mcc_generated_files/mcc.h"
#include "main.h"
#include "motion.h"

void applicationTask(void) {
    // Add your application code
    MTOUCH_Service_Mainloop();
}

void processButtonTouch(enum mtouch_button_names button) {
    // feedback LEDs are active low
    switch(button) {
        case Button1:
            TMR1_StartTimer();
            gButton1Pressed = true;
            // give LED response when brightness is not maximum
            LED1_SetLow();
            if(modeFlag == 0 && activeHours == 1) {
                modeFlag = 1; // if in active hours, button 1 toggles between auto/manual mode
            }
            else if(modeFlag == 1 && activeHours == 1){
                modeFlag = 0;
            } // if not in active hours, button 1 does nothing
            break;
        case Button2: 
            TMR3_StartTimer();
            gButton2Pressed = true;
            // give LED response when brightness is not minimum
            LED2_SetLow();
            if(activeHours == 0 && offFlag == 0) { // if not in active hours, button 2 serves as a on/off swtich
                PWM6_LoadDutyValue(1023);
                PWM8_LoadDutyValue(1023);
                offFlag = 1;
            }
            else if(activeHours == 0 && offFlag == 1) {
                PWM6_LoadDutyValue(0);
                PWM8_LoadDutyValue(0);
                offFlag = 0;
            }
            if(activeHours == 1 && modeFlag == 1){
                // change color temperatures
                if(xwarm == 0 && warm == 0 && mid == 0 && cold == 0 && xcold == 0) {
                    xwarm = 1; // state 0: off
                }
                else if(xwarm == 1 && warm == 0 && mid == 0 && cold == 0 && xcold == 0) {
                    warm = 1; // state 1: 2700K
                }
                else if(xwarm == 1 && warm == 1 && mid == 0 && cold == 0 && xcold == 0) {
                    mid = 1; // state 2: 3500K
                }
                else if(xwarm == 1 && warm == 1 && mid == 1 && cold == 0 && xcold == 0) {
                    cold = 1; // state 3: 4100K
                }
                else if(xwarm == 1 && warm == 1 && mid == 1 && cold == 1 && xcold == 0) {
                    xcold = 1; // state 4: 5500K
                }
                else if(xwarm == 1 && warm == 1 && mid == 1 && cold == 1 && xcold == 1) {
                    xwarm = 0; // state 5: 6500K and reset the flags
                    warm = 0;
                    mid = 0;
                    cold = 0;
                    xcold = 0;
                }
            }
            break;       
        default: 
            break;
    }    
}
 
void processButtonRelease(enum mtouch_button_names button) {
    uint16_t timerCount;
    // feedback LEDs are active low
    switch(button) { // we are not using this but it can be programmed as desired
        case Button1: 
            TMR1_StopTimer();
            timerCount = TMR1_ReadTimer();
            TMR1_WriteTimer(0x0000);
            gButton1Pressed = false;
            LED1_SetHigh();
            if(timerCount > TIMER_3s) {
                // timeout event, use the previous value
                return;
            }
            // check if button 2 is also pressed, if yes make a flag high
            if(gButton2Pressed) {
                gWaitingForButton2Release = true;
            } else {
                // check if button 2 was waiting for button 1 release , if yes change the color
                if(gWaitingForButton1Release) {
                    gWaitingForButton1Release = false;                                    
                } else {
                    // if button2 was not pressed , increase the brightness
                }
            }                        
            break;
        case Button2:
            TMR3_StopTimer();
            timerCount = TMR3_ReadTimer();
            TMR3_WriteTimer(0x0000);
            gButton2Pressed = false;
            LED2_SetHigh();
            if(timerCount > TIMER_3s) {
                // timeout event, use the previous value
                return;
            }
            // check if button 1 is also pressed, if yes make a flag high
            if(gButton1Pressed) {
                gWaitingForButton1Release = true;
            } else {
                if(gWaitingForButton2Release) {         
                } else {
                }
            }
            break;        
        default: 
            break;
    }  
}

