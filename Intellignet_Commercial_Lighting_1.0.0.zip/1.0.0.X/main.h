/* 
 * File:   main.h
 * Author: Mouser Electronics, Inc.
 *
 * Created on June 28, 2021, 2:40 PM
 */

/*
       Copyright (C) 2021  Mouser Electronics

       This program is free software: you can redistribute it and/or modify

       it under the terms of the GNU General Public License as published by

       the Free Software Foundation, either version 3 of the License, or

       any later version.

       This program is distributed in the hope that it will be useful,

       but WITHOUT ANY WARRANTY; without even the implied warranty of

       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

       GNU General Public License for more details.

       You should have received a copy of the GNU General Public License

       along with this program.  If not, see <http://www.gnu.org/licenses/>.

              Project BOM:

              (BOM weblink here)

     

*/

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "mcc_generated_files/mcc.h"
    
volatile bool gButton1Pressed;
volatile bool gButton2Pressed;
volatile bool gWaitingForButton1Release;
volatile bool gWaitingForButton2Release;

int sec; // global variables for time
int min;
int hour;
int day;

bool modeFlag = 0; // flag for auto/manual mode
bool activeHours; // flag for active/inactive hours
bool offFlag = 0; // flag for on/off during inactive hours
bool dark = 0; // flag for ambient light

bool xwarm = 0; //flags for different color temperatures in manual mode
bool warm = 0;
bool mid = 0;
bool cold = 0;
bool xcold = 0;

/**
   @Param
    none
   @Returns
    none
   @Description
    main application task
   @Example
    applicationTask();
 */
void applicationTask(void);

/**
   @Param
    none
   @Returns
    button number
   @Description
    callback function for button press
   @Example
    
 */
void processButtonTouch(enum mtouch_button_names button);

/**
   @Param
    none
   @Returns
    button number
   @Description
    callback function for button release
   @Example
    
 */
void processButtonRelease(enum mtouch_button_names button);


#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

