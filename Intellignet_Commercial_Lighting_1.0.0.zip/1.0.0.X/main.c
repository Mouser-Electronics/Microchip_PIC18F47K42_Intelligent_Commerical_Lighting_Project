/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC18F47K42
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

/*

 * Main Program 

       Copyright (C) 2021  Mouser Electronics

       This program is free software: you can redistribute it and/or modify

       it under the terms of the GNU General Public License as published by

       the Free Software Foundation, either version 3 of the License, or

       any later version.

       This program is distributed in the hope that it will be useful,

       but WITHOUT ANY WARRANTY; without even the implied warranty of

       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

       GNU General Public License for more details.

       You should have received a copy of the GNU General Public License

       along with this program.  If not, see <http://www.gnu.org/licenses/>.

              Project BOM:

              (BOM weblink here)     

*/

#include "mcc_generated_files/mcc.h"
#include "main.h"
#include "ambient.h"
#include "touch_app.h"
#include "mcc_generated_files/rtcc5_example.h"
#include "motion.h"
#include "mcc_generated_files/pwm6.h"
#include "mcc_generated_files/pwm8.h"

/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();
    
    // setup callback functions for button press and release
    MTOUCH_Button_SetPressedCallback(processButtonTouch);
    MTOUCH_Button_SetNotPressedCallback(processButtonRelease);
    
    //turn OFF touch button LEDs
    LED1_SetHigh(); 
    LED2_SetHigh();
    
    rtcc5_Set(); // set time
    
    disarmMotionSensor();
    PWM6_LoadDutyValue(0); // turn off the light
    PWM8_LoadDutyValue(0);

    while (1)
    {
        sec = rtcc5_ReadSec(); // fetch current time
        min = rtcc5_ReadMin();
        hour = rtcc5_ReadHour();
        day = rtcc5_ReadDay();
        applicationTask(); // run the touch service routine
        if(day == 6 || day  == 0) { // Saturday or Sunday
            activeHours = 0; // set hours as inactive; light is off by default
            armMotionSensor(); // arm motion sensor
        }
        else { // Monday through Friday but the time is later than 19:00 or earlier than 7:00
            if(hour >= 19 || hour < 7) {
                if(hour == 19 && min == 0 && sec == 1) { // 2700K from 16:00 to 19:00
                    PWM6_LoadDutyValue(0);
                    PWM8_LoadDutyValue(0);
                }
                activeHours = 0; // set hours as inactive; light is off by default
                armMotionSensor(); // arm motion sensor
            }
            else {
                applicationTask();
                activeHours = 1; // set the hours as active
                offFlag = 0; // clear the off flag
                disarmMotionSensor(); // disarm motion sensor
                while(min % 10 == 0 && sec == 1){ // every 10 minutes, check ambient light
                    sec = rtcc5_ReadSec(); // fetch current time
                    min = rtcc5_ReadMin();
                    hour = rtcc5_ReadHour();
                    day = rtcc5_ReadDay();
                    ambient_test();
                }
                if(modeFlag == 0) { // auto mode
                    if(dark == 0){ // if there is enough ambient light
                        if(hour < 9) { // 2700K from 7:00 to 9:00
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(0);
                            // 2700K
                        }
                        if(hour >= 9 && hour < 10) { // 3500K from 9:00 to 10:00
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(306);
                            // 3500K
                        }
                        if(hour >= 10 && hour < 11) { // 4100K from 10:00 to 11:00
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(1023);
                            // 4100K
                        }
                        if(hour >= 11 && hour < 12) { // 5500K from 11:00 to 12:00
                            PWM6_LoadDutyValue(101);
                            PWM8_LoadDutyValue(1023);
                            // 5500K
                        }
                        if(hour >= 12 && hour < 13) { // 6500K from 12:00 to 13:00
                            PWM6_LoadDutyValue(0);
                            PWM8_LoadDutyValue(1023);
                            // 6500K
                        }
                        if(hour >= 13 && hour < 14) { // 5500K from 13:00 to 14:00
                            PWM6_LoadDutyValue(101);
                            PWM8_LoadDutyValue(1023);
                            // 5500K
                        }
                        if(hour >= 14 && hour < 15) { // 4100K from 14:00 to 15:00
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(1023);
                            // 4100K
                        }
                        if(hour >= 15 && hour < 16) { // 3500K from 15:00 to 16:00
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(306);
                            // 3500K
                        }
                        if(hour >= 16) { // 2700K from 16:00 to 19:00
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(0);
                            // 2700K
                        }
                    }
                    else{ // if there is not enough ambient light, turn on both channels to maximum brightness
                        PWM6_LoadDutyValue(1023);
                        PWM8_LoadDutyValue(1023);
                    }
            }
                else if(modeFlag == 1) { // manual mode
                    dark = 0; // clear the dark flag
                    while(modeFlag == 1){
                        applicationTask(); // run the touch service routine since it is in a while loop
                        if(xwarm == 0 && warm == 0 && mid == 0 && cold == 0 && xcold == 0){
                            PWM6_LoadDutyValue(0); // detailed explanation for each state can be found in touch_app.c
                            PWM8_LoadDutyValue(0);
                            // turn off light
                        }
                        if(xwarm == 1 && warm == 0 && mid == 0 &&cold == 0 && xcold == 0) {
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(0);
                            // 2700K
                        }
                         if(xwarm == 1 && warm == 1 && mid == 0 && cold == 0 && xcold == 0) {
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(306);
                            // 3500K
                        }
                        if(xwarm == 1 && warm == 1 && mid == 1 && cold == 0 && xcold == 0) {
                            PWM6_LoadDutyValue(1023);
                            PWM8_LoadDutyValue(1023);
                            // 4100K
                        }
                        if(xwarm == 1 && warm == 1 && mid == 1 && cold == 1 && xcold == 0) {
                            PWM6_LoadDutyValue(101);
                            PWM8_LoadDutyValue(1023);
                            // 5500K
                        }
                        if(xwarm == 1 && warm == 1 && mid == 1 && cold == 1 && xcold == 1) {
                            PWM6_LoadDutyValue(0);
                            PWM8_LoadDutyValue(1023);
                            // 6500K
                        }
                    }
                }
            }
        }
        /*
        disarmMotionSensor();
        applicationTask();
        min = rtcc5_ReadMin();
        
        if(min % 30 == 0) {
            ambient_test();
        }
        
        while(min % 31 == 0) {
            min = rtcc5_ReadMin();
            armMotionSensor();
            test_SetLow();
        }
        */
    }
}
/**
 End of File
*/